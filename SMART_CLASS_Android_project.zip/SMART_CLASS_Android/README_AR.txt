SMART CLASS — مشروع Android لتجهيزه كملف APK

مهم: هذا مجلد مشروع Android Studio، وليس ملف APK جاهزًا للتثبيت. يلزم بناء المشروع باستخدام Android Studio على كمبيوتر متصل بالإنترنت، لأن بيئة الإنشاء هنا لا تحتوي على Android SDK أو أدوات بناء APK.

طريقة إخراج APK:
1) فك ضغط SMART_CLASS_Android.zip على كمبيوتر.
2) ثبّت Android Studio وافتح هذا المجلد من File > Open.
3) انتظر Gradle Sync، ووافق على تنزيل Android SDK المطلوبة إذا طُلب منك.
4) اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
5) بعد نجاح البناء، ستجد الملف غالبًا في app/build/outputs/apk/debug/app-debug.apk.
6) انقل app-debug.apk إلى هاتف Android وثبّته. قد يطلب الهاتف السماح بالتثبيت من هذا المصدر.

التطبيق يعرض واجهة SMART CLASS محليًا داخل WebView، لكنه يحتاج الإنترنت لتحميل مكتبة Three.js من CDN كي يعمل مشهد 3D. يعتمد الأداء على إصدار Android System WebView والجهاز.
